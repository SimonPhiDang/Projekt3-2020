#include "orderClass.h"
#include <uWS/uWS.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>


orderClass::orderClass(/* args */)
{
}

void orderClass::setOrder(int table, int beerAmount){
    setTable(table);
    setBeerAmount(beerAmount);
}

int orderClass::getTable(){
    return table_;
}

int orderClass::getBeerAmount(){
    return beerAmount_;
}

bool orderClass::checkOrder(){
    cout << "Checking Order: Bord: " << table_ << ". Antal øl: " << beerAmount_ << endl << endl;
    int fd;
    char readBuf[10];
    int num_read;
    int status;

    fd = open("/dev/i2c-1", O_RDWR);
    if (fd == -1)
    {
        std::cout << "Error on fd" << std::endl;
    };

    status = ioctl(fd,0x0703, 0x08);
    if (status > 0)
    {
        std::cout << "Error on status" << std::endl;
    }
    num_read = read(fd,readBuf,1);
    if (num_read != 1)
    {
        std::cout << "Error on num_read" << std::endl;
    };

    printf("Checking num_read: %d", readBuf[0]);
    cout << endl << endl;
    //close(fd);
    return 0;
}

bool orderClass::checkWeight(){

    int fd;
    char readBuf[10];
    int num_read;
    int status;

    fd = open("/dev/i2c-1", O_RDWR);
    if (fd == -1)
    {
        std::cout << "Error on fd" << std::endl;
    };

    status = ioctl(fd,0x0703, 0x08);
    if (status > 0)
    {
        std::cout << "Error on status" << std::endl;
    }
    num_read = read(fd,readBuf,1);
    if (num_read != 1)
    {
        std::cout << "Error on num_read" << std::endl;
    };
    //close(fd);

    //printf("Checking num_read: %d", readBuf[0]);
    //cout << endl << endl;

    if (readBuf[0] == 1)
    {
        //cout << "Beertress is empty" << endl;
        return 0; //return false når der mangler øl
    }
    else
    {
        //cout << "Beertress is full" << endl;
        return 1; //return true når der ikke mangler øl
    }
}

void orderClass::sendOrderToPSoC(){

    cout << "Bord: " << table_ << " har ordret " << beerAmount_ << " øl. Sender til PSoC" << endl << endl;;
    int fd;
    char writeBuf[10];
    int num_write;
    int status;

    fd = open("/dev/i2c-1", O_RDWR);
    if (fd == -1)
    {
        std::cout << "Error on fd" << std::endl;
    };

    status = ioctl(fd,0x0703, 0x08);
    if (status > 0)
    {
        std::cout << "Error on status" << std::endl;
    }
    
    //writeBuf[0] sættes konstant til 1 eftersom den udgave af beertress vi arbejder med kun kan håndtere øl
    writeBuf[0] = 0b00000001;
    
    switch (table_)
    {
    case 1:
        writeBuf[1] = 0b00000001;
        break;
    case 2:
        writeBuf[1] = 0b00000010;
        break;
    default:
        break;
    }

    switch (beerAmount_)
    {
    case 1:
        writeBuf[2] = 0b00000001;
        break;
    case 2:
        writeBuf[2] = 0b00000010;
        break;
    case 3:
        writeBuf[2] = 0b00000011;
        break;
    default:
        break;
    }

    num_write = write(fd,writeBuf,3);
    if (num_write != 3)
    {
        std::cout << "Error on num_write" << std::endl;
    };
    
    printf("Checking num_write: %d - %d - %d", writeBuf[0], writeBuf[1], writeBuf[2]);
    //printf("Checking num_write: %d", writeBuf[0]);
    cout << endl << endl;
    //close(fd);
}


void orderClass::setBeerAmount(int beerAmount){
    beerAmount_ = beerAmount;
}

void orderClass::setTable(int table){
    table_ = table;
}