#include <linux/gpio.h> 
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/module.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Beertress");
MODULE_DESCRIPTION("myGPIO_Driver");

#define ADC_MAJOR 63
#define ADC_MINOR 0

static int devno;
static struct  cdev my_cdev;
struct file_operations my_fops;
int gpio = 25;

static int mygpio_init(void)
{ 
    // Request GPIO
    int err_reg = 0;
    err_reg = gpio_request(gpio, "orderCompleteGPIO");
    if(err_reg < 0)
    {
        printk(KERN_ALERT "Error with request!\n");
        goto err_exit;
    }
    printk(KERN_ALERT "Request was successfull!\n");

    // Set GPIO direction (in or out)
    err_reg = gpio_direction_input(gpio);
    if(err_reg < 0)
    {
        printk(KERN_ALERT "Error with direction!\n");
        goto err_exit;
    }
    printk(KERN_ALERT "Direction was successfull!\n");

    // Make device no (vælg - Enten bruger I statisk eller også bruger I dynamisk major/minor nummer allokering) 
    devno = MKDEV(ADC_MAJOR, ADC_MINOR);
    printk(KERN_ALERT "MKDEV was successfull!\n");

    // Register Device
    err_reg = register_chrdev_region(devno, 1, "orderCompleteGPIO");
    if (err_reg < 0)
    {
        printk(KERN_ALERT "Error with register!\n");
        goto err_free_buf;
    }
    printk(KERN_ALERT "Register was successfull!\n");
       
    // Cdev Init
    cdev_init(&my_cdev, &my_fops);
    printk(KERN_ALERT "cdev_init was successfull!\n");
    // Add Cdev
    err_reg = cdev_add(&my_cdev, devno, 1);
    if (err_reg < 0)
    {
        printk(KERN_ALERT "Error with cdev_add!\n");
        goto err_dev_unregister;
    }
    printk(KERN_ALERT "cdev_add was successfull!\n");
    

    printk(KERN_ALERT "mygpio_init was a success!\n");
    return 0; //Success



    printk(KERN_ALERT "Starting goto!\n");
    err_dev_unregister:
        unregister_chrdev_region(devno, 1);
        printk(KERN_ALERT "err_dev_unregister!\n");
    err_free_buf:
        gpio_free(gpio);
        printk(KERN_ALERT "err_free_buf!\n");
    err_exit:
        return err_reg;
        printk(KERN_ALERT "err_exit!\n");
}

static void mygpio_exit(void)
{
    // Delete Cdev
    cdev_del(&my_cdev);
    // Unregister Device
    unregister_chrdev_region(devno, 1);
    // Free GPIO
    gpio_free(gpio);
    printk(KERN_ALERT "mygpio_exit was a success!\n");
}

int mygpio_open(struct inode *inode, struct file *filep)
{
    int major, minor;

    major = MAJOR(inode->i_rdev);
    minor = MINOR(inode->i_rdev);
    printk("Opening MyGpio Device [major], [minor]: %i, %i\n", major, minor);
    return 0;
}

int mygpio_release(struct inode *inode, struct file *filep)
{
    int minor, major;

    major = MAJOR(inode->i_rdev);
    minor = MINOR(inode->i_rdev);
    printk("Closing/Releasing MyGpio Device [major], [minor]: %i, %i\n", major, minor);

return 0;
}

struct file_operations my_fops = 
{
    .open = mygpio_open,
    .release = mygpio_release,
    .read = mygpio_read,
};

module_init(mygpio_init);
module_exit(mygpio_exit);