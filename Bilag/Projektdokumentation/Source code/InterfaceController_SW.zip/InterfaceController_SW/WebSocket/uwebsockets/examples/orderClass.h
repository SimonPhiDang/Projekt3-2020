#include <iostream>
#include <stdlib.h>
using namespace std;

class orderClass
{
public:
    orderClass(/* args */);
    void setOrder(int, int);


    int getTable(); 
    int getBeerAmount();
    void setBeerAmount(int);
    void setTable(int);
    bool checkWeight();
    bool checkOrder();
    void sendOrderToPSoC();
     
private:
    int table_;
    int beerAmount_; 
    
};
